import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import "./globals.css"
import { GenerationProvider } from "@/contexts/generation-context"
import { StemsProvider } from "@/contexts/stems-context"
import { GenerationSidebarWrapper } from "@/components/generation-sidebar-wrapper"
import { StemsIndicator } from "@/components/stems-indicator"
import { PersistentPlayer } from "@/components/persistent-player"
import { MobileNav } from "@/components/mobile-nav"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DUA Music - AI Music Studio",
  description: "Create, edit, and manage your music with AI-powered tools",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`font-sans antialiased relative`}>
        <div className="fixed inset-0 -z-10">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: "url(/images/cosmic-background.jpg)",
              filter: "blur(80px)",
              transform: "scale(1.1)",
            }}
          />
          {/* Dark overlay for better contrast and readability */}
          <div className="absolute inset-0 bg-black/40" />
        </div>

        <GenerationProvider>
          <StemsProvider>
            {children}
            <GenerationSidebarWrapper />
            <PersistentPlayer />
            <MobileNav />
            <StemsIndicator />
          </StemsProvider>
        </GenerationProvider>
      </body>
    </html>
  )
}
